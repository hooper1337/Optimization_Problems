//
// Created by mferreira on 1/12/22.
//

#ifndef TESTE_ALGORITMO_H
#define TESTE_ALGORITMO_H

#include "utils.h"

int trepaColinas(int solucao[], int *matriz, int vertices, int iteracoes);
int recristalizacao_simulada(int sol[], int *mat, int vert, int num_iter);

#endif //TESTE_ALGORITMO_H
