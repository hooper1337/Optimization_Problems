//
// Created by mferreira on 1/12/22.
//

#ifndef TESTE_FUNCAO_H
#define TESTE_FUNCAO_H

#include "utils.h"

int calculaFitness(int solucaoAtual[], int *matriz, int vertices);
void repara_sol(int solucaoAtual[], int *matriz, int vertices);

#endif //TESTE_FUNCAO_H
